/**
 * Contains the shared values accessed by both execution threads.
 */
public class SharedState {

    int a1;
    int a2;
    int a3;

    int b1;
    int b2;
    int b3;
}