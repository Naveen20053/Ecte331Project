/**
 * Runs multiple synchronization tests between ThreadA and ThreadB.
 * Each iteration verifies that the shared variables produce the expected
 * results after both threads complete execution.
 */
public class Main {

    private static final int EXPECTED_A1 = 125250;
    private static final int EXPECTED_B1 = 31375;
    private static final int EXPECTED_B2 = 145350;
    private static final int EXPECTED_A2 = 190500;
    private static final int EXPECTED_B3 = 270700;
    private static final int EXPECTED_A3 = 350900;

    public static void main(String[] args) throws InterruptedException {

        int totalRuns = 20000;
        int failedRuns = 0;

        long start = System.nanoTime();

        for (int run = 1; run <= totalRuns; run++) {

            boolean display = (run == 1);

            SharedState data = new SharedState();

            Signal a1Ready = new Signal();
            Signal b2Ready = new Signal();
            Signal a2Ready = new Signal();
            Signal b3Ready = new Signal();

            ThreadA threadA =
                    new ThreadA(data, a1Ready, b2Ready, a2Ready, b3Ready, display);

            ThreadB threadB =
                    new ThreadB(data, a1Ready, b2Ready, a2Ready, b3Ready, display);


            threadA.start();
            threadB.start();

            threadA.join();
            threadB.join();


            boolean correct =
                    data.a1 == EXPECTED_A1 &&
                    data.b1 == EXPECTED_B1 &&
                    data.b2 == EXPECTED_B2 &&
                    data.a2 == EXPECTED_A2 &&
                    data.b3 == EXPECTED_B3 &&
                    data.a3 == EXPECTED_A3;


            if (!correct) {
                failedRuns++;

                System.out.println("FAILED RUN " + run);
                System.out.println(
                        "A1=" + data.a1 +
                        " B1=" + data.b1 +
                        " B2=" + data.b2 +
                        " A2=" + data.a2 +
                        " B3=" + data.b3 +
                        " A3=" + data.a3);
            }


            if (run == 1 || run % 5000 == 0) {

                System.out.println(
                        "Run #" + run +
                        " | A1=" + data.a1 +
                        " | B1=" + data.b1 +
                        " | B2=" + data.b2 +
                        " | A2=" + data.a2 +
                        " | B3=" + data.b3 +
                        " | A3=" + data.a3 +
                        (correct ? " [PASS]" : " [FAIL]"));
            }
        }


        long timeTaken =
                (System.nanoTime() - start) / 1_000_000;


        System.out.println("\n===== TEST RESULTS =====");
        System.out.println("Iterations : " + totalRuns);
        System.out.println("Time       : " + timeTaken + " ms");
        System.out.println("Failures   : " + failedRuns);

        System.out.println(
                failedRuns == 0
                ? "Synchronization verified successfully."
                : "Synchronization errors detected.");
    }
}