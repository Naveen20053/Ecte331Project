/**
 * Handles Thread B operations:
 * B1 -> B2 -> B3.
 * Thread B waits for required results produced by Thread A.
 */
public class ThreadB extends Thread {


    private final SharedState state;
    private final Signal afterA1;
    private final Signal afterB2;
    private final Signal afterA2;
    private final Signal afterB3;
    private final boolean verbose;



    public ThreadB(SharedState state, Signal afterA1, Signal afterB2,
                   Signal afterA2, Signal afterB3, boolean verbose) {

        super("ThreadB");

        this.state = state;
        this.afterA1 = afterA1;
        this.afterB2 = afterB2;
        this.afterA2 = afterA2;
        this.afterB3 = afterB3;
        this.verbose = verbose;
    }



    @Override
    public void run() {


        state.b1 = SumUtil.sumTo(250);


        if (verbose)
            System.out.println("ThreadB finished B1 = " + state.b1);



        try {
            afterA1.await();

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
            return;
        }



        state.b2 = state.a1 + SumUtil.sumTo(200);


        if (verbose)
            System.out.println("ThreadB finished B2 = " + state.b2);



        afterB2.signal();




        try {
            afterA2.await();

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
            return;
        }




        state.b3 = state.a2 + SumUtil.sumTo(400);



        if (verbose)
            System.out.println("ThreadB finished B3 = " + state.b3);



        afterB3.signal();
    }
}