/**
 * Provides a simple thread synchronization mechanism.
 * A thread waits until another thread activates the signal.
 */
public class Signal {

    private boolean active = false;


    /**
     * Pauses execution until the signal is activated.
     */
    public synchronized void await() throws InterruptedException {

        while (!active) {
            wait();
        }
    }


    /**
     * Releases waiting threads by activating the signal.
     */
    public synchronized void signal() {

        active = true;
        notifyAll();
    }
}