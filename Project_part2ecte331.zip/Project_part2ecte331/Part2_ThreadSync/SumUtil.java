/**
 * Provides helper methods for calculating iterative sums.
 */
public class SumUtil {


    /**
     * Calculates the sum from zero up to the given number.
     */
    public static int sumTo(int limit) {

        int sum = 0;

        for (int number = 0; number <= limit; number++) {
            sum += number;
        }

        return sum;
    }
}