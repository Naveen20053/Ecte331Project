package projectpart3forecte331;

/**
 * Task 3: classic priority inversion. Logger (low) acquires the resource
 * and holds it for a long simulated task. Shortly after, SafetyMonitor
 * (high) requests the resource and blocks. Shortly after that,
 * MotionPlanner (medium) starts CPU-bound work that competes for the
 * processor, delaying Logger — and therefore SafetyMonitor.
 */
public class Task3_PriorityInversionDemo {

    public static void main(String[] args) throws Exception {

        RobotTaskThread.warmUp();

        EventLogger logger = new EventLogger("task3_log.txt");

        MotorController controller = new MotorController(
                MotorController.PriorityMode.NONE,
                0,
                logger
        );

        RobotTaskThread lowLogger = new RobotTaskThread(
                "Logger",
                Thread.MIN_PRIORITY,
                controller,
                0,
                4000,
                1,
                logger,
                true
        );

        RobotTaskThread highSafety = new RobotTaskThread(
                "SafetyMonitor",
                Thread.MAX_PRIORITY,
                controller,
                0,
                200,
                1,
                logger,
                false
        );

        CpuBoundThread mediumPlanner = new CpuBoundThread(
                "MotionPlanner",
                Thread.NORM_PRIORITY,
                100000000,
                logger
        );

        lowLogger.start();

        Thread.sleep(300); // Allow Logger to acquire MotorController first

        highSafety.start();

        Thread.sleep(500); // Allow SafetyMonitor to become blocked

        mediumPlanner.start();

        lowLogger.join();
        highSafety.join();
        mediumPlanner.join();

        logger.log(
            "RESULT: SafetyMonitor waited "
            + highSafety.getLastWaitMillis()
            + " ms for the MotorController "
            + "(priority inversion baseline, no management)."
        );

        logger.close();
    }
}