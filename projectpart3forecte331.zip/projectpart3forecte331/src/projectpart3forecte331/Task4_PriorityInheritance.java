package projectpart3forecte331;

/**
 * Task 4: priority inversion with priority inheritance enabled.
 * Logger (low priority) acquires the resource first, SafetyMonitor
 * (high priority) blocks waiting for it, and MotionPlanner (medium priority)
 * competes for CPU time. Priority inheritance temporarily boosts Logger's
 * priority to reduce the waiting time of SafetyMonitor.
 */
public class Task4_PriorityInheritanceDemo {

    public static void main(String[] args) throws Exception {

        RobotTaskThread.warmUp();

        EventLogger logger = new EventLogger("task4_log.txt");

        MotorController controller = new MotorController(
                MotorController.PriorityMode.INHERITANCE,
                0,
                logger
        );

        RobotTaskThread lowLogger = new RobotTaskThread(
                "Logger",
                Thread.MIN_PRIORITY,
                controller,
                0,
                4000,
                1,
                logger,
                true
        );

        RobotTaskThread highSafety = new RobotTaskThread(
                "SafetyMonitor",
                Thread.MAX_PRIORITY,
                controller,
                0,
                200,
                1,
                logger,
                false
        );

        CpuBoundThread mediumPlanner = new CpuBoundThread(
                "MotionPlanner",
                Thread.NORM_PRIORITY,
                100000000,
                logger
        );

        lowLogger.start();

        Thread.sleep(300); // Allow Logger to acquire MotorController first

        highSafety.start();

        Thread.sleep(500); // Allow SafetyMonitor to become blocked

        mediumPlanner.start();

        lowLogger.join();
        highSafety.join();
        mediumPlanner.join();

        logger.log(
            "RESULT: SafetyMonitor waited "
            + highSafety.getLastWaitMillis()
            + " ms for the MotorController "
            + "(priority inheritance enabled)."
        );

        logger.close();
    }
}