package projectpart3forecte331;

/**
 * A thread that performs CPU-intensive operations for a fixed number of
 * iterations without accessing the shared resource. Used to simulate a
 * medium-priority task competing for CPU time during the priority inversion
 * demonstration (Task 3).
 */
public class CpuBoundThread extends Thread {

    private final long iterations;
    private final EventLogger logger;

    public CpuBoundThread(String name, int priority, long iterations, EventLogger logger) {
        super(name);
        setPriority(priority);
        this.iterations = iterations;
        this.logger = logger;
    }

    @Override
    public void run() {
        logger.log(getName() + " started CPU-bound execution (priority="
                + getPriority() + "), does not access MotorController");

        long result = 0;

        for (long i = 0; i < iterations; i++) {
            result += i;
        }

        logger.log(getName() + " completed CPU-bound execution after "
                + iterations + " iterations.");
    }
}