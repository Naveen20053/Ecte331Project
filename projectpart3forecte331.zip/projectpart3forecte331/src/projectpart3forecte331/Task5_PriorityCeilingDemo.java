package projectpart3forecte331;

/**
 * Task 5: priority inversion with priority ceiling enabled.
 * Logger (low priority) acquires the MotorController and is immediately
 * raised to the ceiling priority. SafetyMonitor (high priority) waits for
 * the resource while MotionPlanner (medium priority) competes for CPU time.
 * The priority ceiling protocol reduces blocking caused by priority inversion.
 */
public class Task5_PriorityCeilingDemo {

    public static void main(String[] args) throws Exception {

        RobotTaskThread.warmUp();

        EventLogger logger = new EventLogger("task5_log.txt");

        MotorController controller = new MotorController(
                MotorController.PriorityMode.CEILING,
                Thread.MAX_PRIORITY,
                logger
        );

        RobotTaskThread lowLogger = new RobotTaskThread(
                "Logger",
                Thread.MIN_PRIORITY,
                controller,
                0,
                4000,
                1,
                logger,
                true
        );

        RobotTaskThread highSafety = new RobotTaskThread(
                "SafetyMonitor",
                Thread.MAX_PRIORITY,
                controller,
                0,
                200,
                1,
                logger,
                false
        );

        CpuBoundThread mediumPlanner = new CpuBoundThread(
                "MotionPlanner",
                Thread.NORM_PRIORITY,
                100000000,
                logger
        );

        lowLogger.start();

        Thread.sleep(300); // Allow Logger to acquire MotorController first

        highSafety.start();

        Thread.sleep(500); // Allow SafetyMonitor to become blocked

        mediumPlanner.start();

        lowLogger.join();
        highSafety.join();
        mediumPlanner.join();

        logger.log(
            "RESULT: SafetyMonitor waited "
            + highSafety.getLastWaitMillis()
            + " ms for the MotorController "
            + "(priority ceiling enabled)."
        );

        logger.close();
    }
}