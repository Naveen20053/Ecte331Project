import java.util.Random;

/**
 * Models an individual altitude sensor used by the drone's
 * Triple Modular Redundancy (TMR) system.
 */
public class Sensor {

    private final String sensorId;
    private final int referenceAltitude;
    private final Random rng = new Random();

    public Sensor(String id, int baselineValue) {
        this.sensorId = id;
        this.referenceAltitude = baselineValue;
    }

    public String getId() {
        return sensorId;
    }

    /**
     * Produces one simulated sensor reading.
     *
     * Probability distribution:
     * 0–14   : sensor failure (throws exception)
     * 15–29  : corrupted value outside the valid range
     * 30–99  : valid altitude reading
     *
     * @return simulated altitude value
     * @throws SensorReadException when the sensor fails
     */
    public int readSensor() throws SensorReadException {

        int randomValue = rng.nextInt(100);

        if (randomValue < 15) {
            throw new SensorReadException(
                    "Sensor " + sensorId
                    + " failed to produce a reading (chance="
                    + randomValue + ").");
        }

        if (randomValue < 30) {
            return 201 + rng.nextInt(100);
        }

        int altitude = referenceAltitude + rng.nextInt(21) - 10;

        if (altitude < 0) {
            altitude = 0;
        } else if (altitude > 200) {
            altitude = 200;
        }

        return altitude;
    }
}