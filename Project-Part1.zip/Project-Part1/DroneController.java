import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Handles altitude estimation using Triple Modular Redundancy (TMR)
 * by comparing readings from three independent sensors.
 */
public class DroneController {

    private final Sensor sensorA;
    private final Sensor sensorB;
    private final Sensor sensorC;

    private int lastKnownAltitude = 100;
    private int failureCount = 0;

    private final PrintWriter logWriter;
    private final SimpleDateFormat timeFormat =
            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public DroneController(Sensor a, Sensor b, Sensor c, String logFileName) throws IOException {
        sensorA = a;
        sensorB = b;
        sensorC = c;
        logWriter = new PrintWriter(new FileWriter(logFileName, true));
    }

    private void log(String message) {
        String logEntry = "[" + timeFormat.format(new Date()) + "] " + message;
        logWriter.println(logEntry);
        logWriter.flush();
    }

    /**
     * Performs one sensor reading cycle and determines
     * the altitude using majority voting.
     *
     * @return selected altitude for the current cycle
     * @throws SystemReliabilityException if two reliability failures
     *         occur back-to-back, triggering SAFE MODE.
     */
    public int processCycle() throws SystemReliabilityException {

        List<String> activeSensorIds = new ArrayList<>();
        List<Integer> sensorReadings = new ArrayList<>();
        List<String> invalidSensors = new ArrayList<>();

        Sensor[] sensorList = { sensorA, sensorB, sensorC };

        for (Sensor sensor : sensorList) {
            try {
                int reading = sensor.readSensor();

                if (reading >= 0 && reading <= 200) {
                    System.out.println("Sensor " + sensor.getId() + " -> " + reading);
                    activeSensorIds.add(sensor.getId());
                    sensorReadings.add(reading);
                } else {
                    System.out.println("Sensor " + sensor.getId() +
                            " -> CORRUPTED reading: " + reading);
                    log("CORRUPTED READING: Sensor " + sensor.getId()
                            + " produced out-of-range value " + reading);
                    invalidSensors.add(sensor.getId());
                }

            } catch (SensorReadException e) {
                System.out.println("Sensor " + sensor.getId()
                        + " -> FAILURE (" + e.getMessage() + ")");
                log("SENSOR FAILURE: " + e.getMessage());
                invalidSensors.add(sensor.getId());
            }
        }

        boolean reliabilityIssue = false;
        int altitudeResult;

        if (sensorReadings.size() < 2) {

            reliabilityIssue = true;
            altitudeResult = lastKnownAltitude;

            System.out.println("RELIABILITY STATUS: FAILURE - fewer than 2 valid readings.");
            log("RELIABILITY FAILURE: fewer than 2 valid readings. Outliers=" + invalidSensors);

        } else {

            Integer votedAltitude =
                    findMajorityAndLogOutlier(activeSensorIds, sensorReadings);

            if (votedAltitude != null) {

                altitudeResult = votedAltitude;
                lastKnownAltitude = altitudeResult;

                System.out.println("VOTING DECISION: Majority value = " + altitudeResult);
                log("MAJORITY DECISION: value=" + altitudeResult
                        + " agreeingSensors outlier(s)=" + invalidSensors);

            } else if (sensorReadings.size() == 3) {

                altitudeResult = lastKnownAltitude;

                System.out.println(
                        "VOTING DECISION: All 3 sensors disagree. Fallback to previous altitude = "
                                + altitudeResult);

                log("FALLBACK DECISION: all three valid readings differ "
                        + sensorReadings + ". Using previous altitude "
                        + altitudeResult);

            } else {

                reliabilityIssue = true;
                altitudeResult = lastKnownAltitude;

                System.out.println(
                        "RELIABILITY STATUS: FAILURE - no majority found (2 valid readings disagree).");

                log("RELIABILITY FAILURE: no majority found. Valid readings="
                        + sensorReadings + " sensors=" + activeSensorIds);
            }
        }

        if (reliabilityIssue) {

            failureCount++;
            System.out.println("Consecutive reliability failures: " + failureCount);

            if (failureCount >= 2) {
                log("SAFE MODE ACTIVATED after " + failureCount
                        + " consecutive reliability failures.");
                System.out.println("*** SAFE MODE ACTIVATED ***");

                throw new SystemReliabilityException(
                        "Two consecutive reliability failures. Entering SAFE MODE.");
            }

        } else {
            failureCount = 0;
        }

        return altitudeResult;
    }

    /**
     * Searches for two matching readings.
     * If found, the remaining sensor is treated as the outlier.
     */
    private Integer findMajorityAndLogOutlier(List<String> sensorIds,
                                              List<Integer> readings) {

        for (int first = 0; first < readings.size(); first++) {

            for (int second = first + 1; second < readings.size(); second++) {

                if (readings.get(first).equals(readings.get(second))) {

                    if (readings.size() == 3) {

                        for (int third = 0; third < readings.size(); third++) {

                            if (third != first && third != second) {
                                System.out.println(
                                        "OUTLIER DETECTED: Sensor " + sensorIds.get(third));

                                log("OUTLIER DETECTED: Sensor "
                                        + sensorIds.get(third)
                                        + " disagreed with majority value "
                                        + readings.get(first));
                            }
                        }
                    }

                    return readings.get(first);
                }
            }
        }

        return null;
    }

    public void close() {
        logWriter.close();
    }
}