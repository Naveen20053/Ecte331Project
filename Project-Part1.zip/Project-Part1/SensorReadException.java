import java.io.IOException;

/**
 * Exception raised whenever a sensor is unable
 * to return a valid reading.
 */
public class SensorReadException extends IOException {

    public SensorReadException(String errorMessage) {
        super(errorMessage);
    }
}