import java.util.Random;

/**
 * Main program that continuously executes sensor polling
 * and altitude voting until SAFE MODE is activated or the
 * maximum number of cycles has been completed.
 */
public class Main {

    public static void main(String[] args) {

        Sensor firstSensor = new Sensor("A", 100);
        Sensor secondSensor = new Sensor("B", 100);
        Sensor thirdSensor = new Sensor("C", 100);

        String logFile =
                "log_" + new Random().nextInt(100000) + ".txt";

        System.out.println("Log file: " + logFile);

        try {

            DroneController droneController =
                    new DroneController(firstSensor, secondSensor, thirdSensor, logFile);

            try {

                int iteration = 1;

                while (iteration <= 50) {

                    System.out.println("\n--- Iteration " + iteration + " ---");

                    int currentAltitude = droneController.processCycle();

                    System.out.println("Current altitude: " + currentAltitude + " m");

                    iteration++;
                }

                System.out.println("\nSimulation completed after 50 cycles without entering SAFE MODE.");

            } catch (SystemReliabilityException e) {

                System.out.println("\nSYSTEM ENTERED SAFE MODE: " + e.getMessage());

            } finally {

                droneController.close();
            }

        } catch (Exception e) {

            System.out.println("Unable to start drone controller: " + e.getMessage());
        }
    }
}